export declare function setProxy(): void;
//# sourceMappingURL=set-proxy.d.ts.map