/**
 * Export feature files corresponding to the default test plan from Xray
 */
export declare function retrieveDefaultTestPlanFeatureFiles(): any;
//# sourceMappingURL=retrieve-default-test-plan-feature-files.d.ts.map