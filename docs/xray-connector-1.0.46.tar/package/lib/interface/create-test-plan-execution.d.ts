/**
 * Creates an execution for test plan in Xray
 */
export declare function createTestPlanExecution(summary: string, description: string, results: JSON, testPlanKey: string, testLabels: string, testFixVersions: string, testEnvironment: string): any;
//# sourceMappingURL=create-test-plan-execution.d.ts.map