import { TestPlan } from '../model';
/**
 * Retrieves the default (Gatling) test plan information from Xray
 */
export declare function retrieveDefaultTestPlanGatlingInfo(): Promise<TestPlan>;
//# sourceMappingURL=retrieve-default-test-plan-gatling-info.d.ts.map