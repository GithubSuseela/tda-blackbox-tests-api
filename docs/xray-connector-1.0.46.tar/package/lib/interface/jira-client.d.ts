export declare function getJiraClient(): any;
export declare function destroyJiraClient(): void;
//# sourceMappingURL=jira-client.d.ts.map