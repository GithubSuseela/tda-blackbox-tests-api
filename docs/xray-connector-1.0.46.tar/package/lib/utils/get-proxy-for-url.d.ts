export declare function getProxyForUrl(url: string): string | undefined;
//# sourceMappingURL=get-proxy-for-url.d.ts.map