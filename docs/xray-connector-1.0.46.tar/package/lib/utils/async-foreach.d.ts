export declare function asyncForEach(array: any[], callback: any): Promise<void>;
//# sourceMappingURL=async-foreach.d.ts.map