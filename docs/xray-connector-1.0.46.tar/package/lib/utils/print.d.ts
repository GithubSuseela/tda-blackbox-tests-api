export declare function print(...args: any[]): void;
//# sourceMappingURL=print.d.ts.map