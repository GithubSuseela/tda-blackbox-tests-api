import { TestSimulationStep } from '.';
export declare class TestSimulation {
    tag: string;
    injectionSteps: TestSimulationStep[];
    constructor();
}
//# sourceMappingURL=test-simulation.d.ts.map