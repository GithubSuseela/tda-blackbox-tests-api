export declare class TestSimulationStep {
    injectionProfile: string;
    users: number;
    duration: number;
    constructor();
}
//# sourceMappingURL=test-simulation-step.d.ts.map