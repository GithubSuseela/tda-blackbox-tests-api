import { TestSimulation } from '.';
export declare class TestPlan {
    successfulRequestsPercent: number | undefined;
    responseTimeMin: number | undefined;
    responseTimeMax: number | undefined;
    responseTimeMean: number | undefined;
    responseTimeStdDev: number | undefined;
    responseTimePercentile50th: number | undefined;
    responseTimePercentile75th: number | undefined;
    responseTimePercentile95th: number | undefined;
    responseTimePercentile99th: number | undefined;
    requestsPerSecond: number | undefined;
    simulations: TestSimulation[];
    constructor();
    static fromXray(object: any): TestPlan;
    private static parseDescriptionLine;
    private static getSimulation;
    private static getStep;
}
//# sourceMappingURL=test-plan.d.ts.map