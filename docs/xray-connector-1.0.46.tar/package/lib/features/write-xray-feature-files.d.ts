export declare function writeXrayFeatureFiles(zippedFeatureFilesContent: any, basedir: string): Promise<void>;
//# sourceMappingURL=write-xray-feature-files.d.ts.map