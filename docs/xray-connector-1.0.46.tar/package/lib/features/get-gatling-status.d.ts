export declare class GatlingAssertion {
    status: boolean;
    message: string;
    constructor(status: boolean, message: string);
}
export declare class GatlingStatus {
    status: string;
    assertions: GatlingAssertion[];
    constructor(status: string, assertions: GatlingAssertion[]);
}
export declare function getGatlingStatus(): GatlingStatus;
//# sourceMappingURL=get-gatling-status.d.ts.map