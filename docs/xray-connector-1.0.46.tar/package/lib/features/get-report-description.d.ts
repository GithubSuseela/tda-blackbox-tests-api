export declare function getReportDescription(): string;
//# sourceMappingURL=get-report-description.d.ts.map