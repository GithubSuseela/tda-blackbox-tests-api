export declare function setGatlingReportsDirectory(gatlingReportsDirectory: string): void;
//# sourceMappingURL=set-gatling-reports-directory.d.ts.map