export declare function setTestPlanFile(testPlanFile: string): void;
//# sourceMappingURL=set-test-plan-file.d.ts.map