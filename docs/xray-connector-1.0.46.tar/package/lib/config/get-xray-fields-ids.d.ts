import { XrayFieldsIds } from '../types';
export declare function getXrayFieldsIds(): XrayFieldsIds;
//# sourceMappingURL=get-xray-fields-ids.d.ts.map