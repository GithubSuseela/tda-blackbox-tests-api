export declare function setGatlingSimulation(gatlingSimulation: string): void;
//# sourceMappingURL=set-gatling-simulation.d.ts.map