export declare function setTestEnvironment(testEnvironment: string): void;
//# sourceMappingURL=set-test-environment.d.ts.map