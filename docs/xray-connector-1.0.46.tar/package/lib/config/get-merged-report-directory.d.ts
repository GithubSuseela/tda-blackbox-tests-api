export declare function getMergedReportDirectory(): string;
//# sourceMappingURL=get-merged-report-directory.d.ts.map