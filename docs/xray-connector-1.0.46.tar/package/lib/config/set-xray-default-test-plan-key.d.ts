export declare function setXrayDefaultTestPlanKey(testPlanKey: string): void;
//# sourceMappingURL=set-xray-default-test-plan-key.d.ts.map