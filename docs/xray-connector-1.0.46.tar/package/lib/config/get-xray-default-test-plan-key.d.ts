export declare function getXrayDefaultTestPlanKey(): string;
//# sourceMappingURL=get-xray-default-test-plan-key.d.ts.map