export declare function setMergedReportDirectory(mergedReportDirectory: string): void;
//# sourceMappingURL=set-merged-report-directory.d.ts.map