export declare function getGatlingReportUrl(): string;
//# sourceMappingURL=get-gatling-report-url.d.ts.map