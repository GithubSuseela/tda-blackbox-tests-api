export declare function getGatlingReportsDirectory(): string;
//# sourceMappingURL=get-gatling-report-directory.d.ts.map