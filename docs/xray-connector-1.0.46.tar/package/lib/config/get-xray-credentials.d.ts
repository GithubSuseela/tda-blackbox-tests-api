import { Credentials } from '../types';
export declare function getXrayCredentials(): Credentials;
//# sourceMappingURL=get-xray-credentials.d.ts.map