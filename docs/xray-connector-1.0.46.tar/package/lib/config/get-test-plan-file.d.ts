export declare function getTestPlanFile(): string;
//# sourceMappingURL=get-test-plan-file.d.ts.map