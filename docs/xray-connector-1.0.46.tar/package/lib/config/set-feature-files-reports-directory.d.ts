export declare function setFeatureFilesReportsDirectory(featureFilesReportDirectory: string): void;
//# sourceMappingURL=set-feature-files-reports-directory.d.ts.map