export declare function getXrayHost(): string;
//# sourceMappingURL=get-xray-host.d.ts.map