export declare function getGatlingSimulation(): string;
//# sourceMappingURL=get-gatling-simulation.d.ts.map