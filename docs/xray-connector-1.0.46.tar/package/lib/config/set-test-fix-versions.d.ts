export declare function setTestFixVersions(testFixVersions: string): void;
//# sourceMappingURL=set-test-fix-versions.d.ts.map