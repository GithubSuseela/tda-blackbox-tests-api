export declare function setFeaturesDownloadDirectory(featureFilesDirectory: string): void;
//# sourceMappingURL=set-features-download-directory.d.ts.map