export declare function getTestFixVersions(): string;
//# sourceMappingURL=get-test-fix-versions.d.ts.map