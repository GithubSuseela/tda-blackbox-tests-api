export declare function getFeaturesDownloadDirectory(): string;
//# sourceMappingURL=get-features-download-directory.d.ts.map