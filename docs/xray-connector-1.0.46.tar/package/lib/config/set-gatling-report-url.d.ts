export declare function setGatlingReportUrl(url: string): void;
//# sourceMappingURL=set-gatling-report-url.d.ts.map