export declare function getTestEnvironment(): string;
//# sourceMappingURL=get-test-environment.d.ts.map