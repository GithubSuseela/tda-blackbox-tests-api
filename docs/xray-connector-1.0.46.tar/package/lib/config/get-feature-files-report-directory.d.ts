export declare function getFeatureFilesReportDirectory(): string;
//# sourceMappingURL=get-feature-files-report-directory.d.ts.map