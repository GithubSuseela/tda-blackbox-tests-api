export declare function getTestLabels(): string;
//# sourceMappingURL=get-test-labels.d.ts.map