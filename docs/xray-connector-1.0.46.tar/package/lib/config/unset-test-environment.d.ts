export declare function unsetTestEnvironment(): void;
//# sourceMappingURL=unset-test-environment.d.ts.map