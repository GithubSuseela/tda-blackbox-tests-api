export declare function setTestLabels(testLabels: string): void;
//# sourceMappingURL=set-test-labels.d.ts.map