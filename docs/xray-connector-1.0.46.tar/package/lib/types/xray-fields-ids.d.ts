export type XrayFieldsIds = {
    testExecutionIssueTypeId: number;
    testExecutionTestPlansFieldId: number;
    testExecutionTestEnvironmentsFieldId: number;
};
//# sourceMappingURL=xray-fields-ids.d.ts.map