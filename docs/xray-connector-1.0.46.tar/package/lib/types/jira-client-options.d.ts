export type JiraClientOptions = {
    strictSSL: boolean;
    protocol: string;
    host: string;
    base: string;
    xrayVersion: string;
    username?: string;
    password?: string;
    bearer?: string;
};
//# sourceMappingURL=jira-client-options.d.ts.map