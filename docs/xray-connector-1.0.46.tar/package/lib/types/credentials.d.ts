export type Credentials = {
    username: string;
    password: string;
    token: string;
};
//# sourceMappingURL=credentials.d.ts.map