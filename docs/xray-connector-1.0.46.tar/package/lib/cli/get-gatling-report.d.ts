export declare function getGatlingReport(): void;
//# sourceMappingURL=get-gatling-report.d.ts.map