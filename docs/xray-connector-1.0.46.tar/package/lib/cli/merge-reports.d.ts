export declare function mergeReports(): void;
//# sourceMappingURL=merge-reports.d.ts.map