export declare function sendReport(): Promise<any>;
export declare function sendReportWrapper(logOutput?: boolean): Promise<void>;
//# sourceMappingURL=send-report.d.ts.map