export declare function analyseXrayError(error: any): string;
//# sourceMappingURL=analyse-xray-error.d.ts.map