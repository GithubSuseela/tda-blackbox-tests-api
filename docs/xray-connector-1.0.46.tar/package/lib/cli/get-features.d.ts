export declare function getFeatures(): Promise<void>;
export declare function getFeaturesWrapper(logOutput?: boolean): Promise<void>;
//# sourceMappingURL=get-features.d.ts.map