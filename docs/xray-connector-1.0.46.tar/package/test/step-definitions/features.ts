import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from 'chai';

import * as fs from 'fs';

import { getFeaturesDownloadDirectory } from '../../src/config';
import { getReportDescription, writeXrayFeatureFiles } from '../../src/features';
import { TestPlan } from '../../src/model';

let zipfileContent: string;
let description: string;
let testPlan: TestPlan;

Given('Xray Connector has retrieved feature files from Xray as a zipfile', function () {
  zipfileContent = fs.readFileSync('test/fixtures/features/ACTIVE.zip', 'binary');
});

When('Xray Connector writes down feature files present in zipfile', async function () {
  await writeXrayFeatureFiles(zipfileContent, getFeaturesDownloadDirectory());
});

When('Xray Connector builds the report description', function () {
  description = getReportDescription();
});

When('Xray Connector gets test plan from {string}', function (path: string) {
  const content: string = fs.readFileSync(path).toString('utf8');
  testPlan = TestPlan.fromXray({ description: content });
});

Then('The report description should be the same as file {string}', function (descriptionFile: string) {
  let descriptionFileContent = fs.readFileSync(descriptionFile, 'binary');
  expect(description).to.equal(descriptionFileContent);
});

Then('The test plan requests per second should be {string}', function (value: string) {
  expect(testPlan.requestsPerSecond).to.equal(parseInt(value, 10));
});

Then('The test plan min response time should be {string}', function (value: string) {
  expect(testPlan.responseTimeMin).to.equal(parseInt(value, 10));
});

Then('The test plan max response time should be {string}', function (value: string) {
  expect(testPlan.responseTimeMax).to.equal(parseInt(value, 10));
});

Then('The test plan mean response time should be {string}', function (value: string) {
  expect(testPlan.responseTimeMean).to.equal(parseInt(value, 10));
});

Then('The test plan std dev response time should be {string}', function (value: string) {
  expect(testPlan.responseTimeStdDev).to.equal(parseInt(value, 10));
});

Then('The test plan 50th percentile response time should be {string}', function (value: string) {
  expect(testPlan.responseTimePercentile50th).to.equal(parseInt(value, 10));
});

Then('The test plan 75th percentile response time should be {string}', function (value: string) {
  expect(testPlan.responseTimePercentile75th).to.equal(parseInt(value, 10));
});

Then('The test plan 95th percentile response time should be {string}', function (value: string) {
  expect(testPlan.responseTimePercentile95th).to.equal(parseInt(value, 10));
});

Then('The test plan 99th percentile response time should be {string}', function (value: string) {
  expect(testPlan.responseTimePercentile99th).to.equal(parseInt(value, 10));
});

Then('The test plan successful requests percent should be {string}', function (value: string) {
  expect(testPlan.successfulRequestsPercent).to.equal(parseInt(value, 10));
});

Then('The test plan should contain simulations', function () {
  expect(testPlan.simulations.length > 0);
});

Then('The first simulation should contain steps', function () {
  expect(testPlan.simulations[0].injectionSteps.length > 0);
});

Then('The first simulation should specify tag {string}', function (value: string) {
  expect(testPlan.simulations[0].tag).to.equal(value);
});

Then('The first step should specify injection profile {string}', function (value: string) {
  expect(testPlan.simulations[0].injectionSteps[0].injectionProfile).to.equal(value);
});

Then('The first step should specify {string} users', function (value: string) {
  expect(testPlan.simulations[0].injectionSteps[0].users).to.equal(parseInt(value, 10));
});

Then('The first step should specify a duration of {string}', function (value: string) {
  expect(testPlan.simulations[0].injectionSteps[0].duration).to.equal(parseInt(value, 10));
});

Then('The test plan should contain no simulation', function () {
  expect(testPlan.simulations.length === 0);
});
