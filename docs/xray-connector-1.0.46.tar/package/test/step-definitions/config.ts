import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from 'chai';

import {
  getXrayHost,
  getXrayCredentials,
  getTestEnvironment,
  getXrayDefaultTestPlanKey,
  getFeaturesDownloadDirectory,
  getFeatureFilesReportDirectory,
  getMergedReportDirectory,
  getGatlingSimulation,
  getGatlingReportUrl,
  getGatlingReportsDirectory,
  setFeaturesDownloadDirectory,
  setFeatureFilesReportsDirectory,
  setMergedReportDirectory,
  setTestEnvironment,
  setXrayDefaultTestPlanKey,
  setGatlingSimulation,
  setGatlingReportUrl,
  setGatlingReportsDirectory,
  unsetTestEnvironment,
  getTestPlanFile,
  setTestPlanFile,
  getTestLabels,
  setTestLabels,
  getTestFixVersions,
  setTestFixVersions,
  getXrayFieldsIds,
} from '../../src/config';

let output: string;
let flag: boolean;
let error: boolean;

Given('{string} environment variable has been set to {string}', function (variable: string, value: string) {
  process.env[variable] = value;
});

Given(/^'(\w+)' environment variable has been set to (true|false)$/, function (variable: string, flag: string) {
  process.env[variable] = flag;
});

Given('{string} environment variable has been unset', function (variable: string) {
  delete process.env[variable];
});

Given('The reference test plan is {string}', function (testPlanKey: string) {
  setXrayDefaultTestPlanKey(testPlanKey);
});

Given('The report test environment is {string}', function (testEnvironment: string) {
  setTestEnvironment(testEnvironment);
});

Given('The report test environment is not set', function () {
  unsetTestEnvironment();
});

Given('The feature files base directory is {string}', function (featureFilesDirectory: string) {
  setFeaturesDownloadDirectory(featureFilesDirectory);
});

Given('The feature files reports directory is {string}', function (featureFilesReportDirectory: string) {
  setFeatureFilesReportsDirectory(featureFilesReportDirectory);
});

Given('The gatling reports directory is {string}', function (gatlingReportsDirectory: string) {
  setGatlingReportsDirectory(gatlingReportsDirectory);
});

Given('The gatling simulation main class is {string}', function (gatlingSimulation: string) {
  setGatlingSimulation(gatlingSimulation);
});

Given('The gatling report url is {string}', function (url: string) {
  setGatlingReportUrl(url);
});

Given('The test plan file is {string}', function (testPlanFile: string) {
  setTestPlanFile(testPlanFile);
});

Given('The test labels are {string}', function (testLabels: string) {
  setTestLabels(testLabels);
});

Given('The test fix versions are {string}', function (testFixVersions: string) {
  setTestFixVersions(testFixVersions);
});

Given('The merged report directory is {string}', function (mergedReportDirectory: string) {
  setMergedReportDirectory(mergedReportDirectory);
});

When(/^Xray Connector reads (.*) configuration$/, function (configuration: string) {
  output = '';
  try {
    error = false;
    switch (configuration) {
      case 'JIRA host':
        output = getXrayHost();
        break;
      case 'JIRA login':
        output = getXrayCredentials().username;
        break;
      case 'JIRA password':
        output = getXrayCredentials().password;
        break;
      case 'JIRA token':
        output = getXrayCredentials().token;
        break;
      case 'JIRA credentials':
        getXrayCredentials();
        break;
      case 'Xray reference test plan':
        output = getXrayDefaultTestPlanKey();
        break;
      case 'Xray environment':
        output = getTestEnvironment();
        break;
      case 'feature files download directory':
        output = getFeaturesDownloadDirectory();
        break;
      case 'feature individual execution reports directory':
        output = getFeatureFilesReportDirectory();
        break;
      case 'merged execution report directory':
        output = getMergedReportDirectory();
        break;
      case 'gatling reports directory':
        output = getGatlingReportsDirectory();
        break;
      case 'gatling simulation main class':
        output = getGatlingSimulation();
        break;
      case 'gatling report url':
        output = getGatlingReportUrl();
        break;
      case 'test plan file':
        output = getTestPlanFile();
        break;
      case 'test labels':
        output = getTestLabels();
        break;
      case 'test fix versions':
        output = getTestFixVersions();
        break;
      case 'Xray test execution custom fields ids':
        output = JSON.stringify(getXrayFieldsIds());
        break;
      default:
        console.log(`No configuration retrieval method has been defined for '${configuration}'.`);
        return false;
    }
  } catch {
    error = true;
  }
});

Then('The value returned should be {string}', function (value: string) {
  expect(output).to.equal(value);
});

Then('The value returned should be undefined', function () {
  expect(output).to.be.undefined;
});

Then('The value returned should be true', function () {
  expect(flag).to.be.true;
});

Then('The value returned should be false', function () {
  expect(flag).to.be.false;
});

Then('A configuration error should be reported', function () {
  expect(error).be.true;
});

Then('No configuration error should be reported', function () {
  expect(error).be.false;
});
