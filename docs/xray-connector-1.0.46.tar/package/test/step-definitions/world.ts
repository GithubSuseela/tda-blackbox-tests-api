import { BeforeAll, Before, After } from '@cucumber/cucumber';
import * as fs from 'fs';
import * as rimraf from 'rimraf';

import { setProxy } from '../../src/interface/set-proxy';
import { destroyJiraClient } from '../../src/interface';

// console.log('JIRA_XRAY_LOGIN:', process.env.JIRA_XRAY_LOGIN);
// console.log('JIRA_XRAY_PROXY:', process.env.JIRA_XRAY_PROXY);

let processEnvironmentBackup: NodeJS.ProcessEnv;

BeforeAll(function () {
  // download-features and reports are used to test directories that already exist
  if (!fs.existsSync('downloaded-features')) {
    fs.mkdirSync('downloaded-features');
  }
  if (!fs.existsSync('reports')) {
    fs.mkdirSync('reports');
  }
});

BeforeAll(function () {
  setProxy();
});

Before(function () {
  // Backup environment variables so that the current scenario may tweak them
  processEnvironmentBackup = JSON.parse(JSON.stringify(process.env)) as NodeJS.ProcessEnv;
});

After(function () {
  // Restore environment variables to their value before the current scenario
  process.env = JSON.parse(JSON.stringify(processEnvironmentBackup)) as NodeJS.ProcessEnv;
  // Remove temporary directory
  rimraf.sync('tmp');
  // Destroy JIRA client so that new configuration parameters may be applied by other scenarios
  destroyJiraClient();
});
