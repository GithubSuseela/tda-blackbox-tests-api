import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from 'chai';
import * as fs from 'fs';

import { getFeaturesWrapper } from '../../src/cli/get-features';
import { mergeReports } from '../../src/cli/merge-reports';
import { sendReportWrapper } from '../../src/cli/send-report';
import { getGatlingReport } from '../../src/cli/get-gatling-report';

let error: boolean;
let errorMessage: string;

Given('A merged report has been generated in {string}', function (directory: string) {
  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory, { recursive: true });
  }
  fs.copyFileSync('test/fixtures/reports/merged/merged-output.json', directory + '/' + 'merged-output.json');
});

When('Xray Connector retrieves feature files from Xray', { timeout: 60 * 1000 }, async function () {
  try {
    error = false;
    await getFeaturesWrapper(false);
  } catch (err) {
    error = true;
    errorMessage = (err as Error).message;
    console.log(errorMessage);
  }
});

When('Xray Connector merges individual feature files test execution reports', function () {
  mergeReports();
});

When('Xray Connector creates merged report from gatling reports', function () {
  getGatlingReport();
});

When('Xray Connector publishes test execution report to Xray', { timeout: 60 * 1000 }, async function () {
  try {
    error = false;
    await sendReportWrapper(false);
  } catch (err) {
    error = true;
    errorMessage = (err as Error).message;
  }
});

Then('An execution error should be reported', function () {
  expect(error).be.true;
});

Then('No execution error should be reported', function () {
  expect(error).be.false;
});

Then('The error message should contain {string}', function (message: string) {
  // console.log(errorMessage);
  expect(errorMessage).contains(message);
});
