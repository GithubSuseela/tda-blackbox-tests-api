import { Given, Then } from '@cucumber/cucumber';
import { expect } from 'chai';
import * as fs from 'fs';

Given('nothing', function () {
  return true;
});

Given(/^Directory '(.*)' (?:does|should) not exist$/, function (directory: string) {
  expect(fs.existsSync(directory)).to.equal(false);
});

Given(/^Directory '(.*)' (?:exists|should exist)$/, function (directory: string) {
  expect(fs.existsSync(directory)).to.equal(true);
});

Given(/^Directory '(.*)' has been created$/, function (directory: string) {
  fs.mkdirSync(directory, { recursive: true });
});

Then(/^File '(.*)' (?:does|should) not exist$/, function (file: string) {
  expect(fs.existsSync(file)).to.equal(false);
});

Then(/^File '(.*)' (?:exists|should exist)$/, function (file: string) {
  expect(fs.existsSync(file)).to.equal(true);
});

Then('File {string} should be the same as {string}', function (obtained: string, expected: string) {
  let obtainedFiledContent = fs.readFileSync(obtained, 'binary');
  let expectedFileContent = fs.readFileSync(expected, 'binary');
  expect(obtainedFiledContent).to.equal(expectedFileContent);
});
