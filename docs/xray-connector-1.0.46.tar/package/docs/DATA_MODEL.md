# xray-connector data model

## Test Plan

| Property                      | Type                  |
|-------------------------------|-----------------------|
| successfulRequestsPercent     | number                |
| responseTimeMin               | number                |
| responseTimeMax               | number                |
| responseTimeMean              | number                |
| responseTimeStdDev            | number                |
| responseTimePercentile50th    | number                |
| responseTimePercentile75th    | number                |
| responseTimePercentile95th    | number                |
| responseTimePercentile99th    | number                |
| requestsPerSecond             | number                |
| simulations                   | TestSimulation[]      |

## Test Simulation

| Property                      | Type                  |
|-------------------------------|-----------------------|
| tag                           | string                |
| injectionSteps                | TestSimulationStep[]  |

## Test Simulation Step

| Property                      | Type                  |
|-------------------------------|-----------------------|
| injectionProfile              | string                |
| users                         | number                |
| duration                      | number                |
