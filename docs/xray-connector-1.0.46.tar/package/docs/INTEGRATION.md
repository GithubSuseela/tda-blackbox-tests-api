# Test Automation Framework integration

To configure xray-connector with **Cypress**, please refer to [this document](integration/CYPRESS.md)

**Karate** and **Gatling** integration is based on **Gradle**. To configure xray-connector with Gradle, please refer to [this document](integration/GRADLE.md)
