# Configuring npm for artifactory

To install xray-connector from **Renault** npm repostory
(mirror of npm and yarn public repository as well as the **npm-renault-local** repository),
you will need to have the necessary repository settings defined in your npm configuration.

## Check current configuration

First, confirm whether the repository is configured or not:

```bash
$ npm config get @rd:registry
```

 * If the output is: `https://artifactory.dt.renault.com/artifactory/api/npm/npm-renault/`, then your configuration should already be correct.

 * If the output is: `undefined` then you need to set the repository configuration.

## Generate npm settings

To generate the relevant configuration parameters, follow these steps:

 * Set the necessary artifactory authentication environment variables:

```bash
$ export ARTIFACTORY_USERNAME=<your IPN>
$ export ARTIFACTORY_APIKEY=<the API key that you can find in your artifactory profile>
```

*Note*: you can log in to artifactory [here](https://artifactory.dt.renault.com/artifactory/). Use SAML SSO to log in.
The API key is in your profile.

 * Run the following command

```bash
$ curl -u $ARTIFACTORY_USERNAME:$ARTIFACTORY_APIKEY https://artifactory.dt.renault.com/artifactory/api/npm/npm-renault/auth/rd | sed "s/:443//g"
```

* The output should be similar to:

```
@rd:registry=https://artifactory.dt.renault.com/artifactory/api/npm/npm-renault/
//artifactory.dt.renault.com/artifactory/api/npm/npm-renault/:_password=<ENCODED PASSWORD>
//artifactory.dt.renault.com/artifactory/api/npm/npm-renault/:username=<IPN>
//artifactory.dt.renault.com/artifactory/api/npm/npm-renault/:email=<EMAIL>
//artifactory.dt.renault.com/artifactory/api/npm/npm-renault/:always-auth=true
```

* You should now append these parameters to your `$HOME/.npmrc` configuration file.

 