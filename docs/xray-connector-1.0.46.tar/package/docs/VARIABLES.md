# xray-connector variables

Several environment variables are necessary for xray-connector to work properly and integrate with your test automation framework.

They may be set in your environment, or in an `.env` file in your project's root directory, which xray-connector will read automatically.

## Connection information

If you're using authentication with user login/password, define the following environment variables:

    JIRA_XRAY_LOGIN=<JIRA account login>
    JIRA_XRAY_PASSWORD=<JIRA account password>

If you're using authentication with user token, define the following environment variables:

    JIRA_XRAY_TOKEN=<JIRA account token>

*Note: if you define both `JIRA_XRAY_LOGIN` / `JIRA_XRAY_PASSWORD` and `JIRA_XRAY_TOKEN`, `JIRA_XRAY_TOKEN` will be used* 

In addition, you may change the default JIRA server host (jira.dt.renault.com), by setting the `JIRA_XRAY_HOST` variable.

If you need a proxy to access the JIRA server, define it in the `JIRA_XRAY_PROXY` variable, for instance:

    JIRA_XRAY_PROXY=https://web-proxy.infra.dub.aws.renault.azn:3128

## Test plan identifier

xray-connector will retrieve tests that associated with the test plan defined by `XC_DEFAULT_TEST_PLAN`.

This variable should be set to the ID of your test plan in JIRA/Xray, for instance:

    XC_DEFAULT_TEST_PLAN=XRAY67658-301

## Directories

xray-connector commands will store and retrieve files in certain locations, that need to be defined:

| Variable | Content | Impacts commands | Frameworks | Default |
|----------|---------|:----------------:|:----------:|---------|
| XC_FEATURES_DOWNLOAD_DIRECTORY | Directory where to store features downloaded from Xray | get&#8209;features | All | downloaded-features |
| XC_MERGED_REPORT_DIRECTORY | Directory where to store merged test execution reports | send&#8209;report<br> build&#8209;report<br> build&#8209;gatling&#8209;report | All | reports/cucumber/merged |
| XC_FEATURES_REPORT_DIRECTORY | Directory where individual features execution reports are stored (depends on your test automation framework and its configuration)| build&#8209;report | Cypress, Cucumber | reports/cucumber |
| XC_GATLING_REPORTS_DIRECTORY | Gatling output folder where reports are generated (depends on your Gatling configuration)| build&#8209;gatling&#8209;report | Gatling ||

## xray-connector behaviour

### Associate environments to reports

Additionally, if you want to associate your test results to an environment, you may specify this environment using the 
`XC_TEST_ENVIRONMENT` variable, for instance:

    XC_TEST_ENVIRONMENT=‘QUA'

### Associate labels to reports

Additionally, if you want to annotate your test results with some labels, you may specify these labels (separated by commas) using the 
`XC_TEST_LABELS` variable, for instance:

    XC_TEST_LABELS=‘my-api,integration'

If you want to annotate your test result with some fix versions (example release version), you may insert these values separated by commas, by using the
`XC_TEST_FIX_VERSIONS` variable, for instance:

    XC_TEST_FIX_VERSIONS=‘R2-3,R2'

## Test automation frameworks specific variables

If you're using xray-connector with Gatling load tests, define the following environment variables:

    XC_GATLING_SIMULATION=<Gatling main simulation class name>
    XC_TEST_PLAN_FILE=<Gatling simulation json file>
    XC_GATLING_REPORT_URL=<URL to Gatling report (optional)>

## Full example

Here is an example of such an `.env` file (for which the test  automation framework is Cucumber):

    JIRA_XRAY_LOGIN=<JIRA login>
    JIRA_XRAY_PASSWORD=<JIRA password>
    JIRA_XRAY_HOST=jira.dt.renault.com
    XC_DEFAULT_TEST_PLAN='XRAY67658-301'
    XC_FEATURES_DOWNLOAD_DIRECTORY='downloaded-features'
    XC_FEATURES_REPORT_DIRECTORY='reports/cucumber'
    XC_MERGED_REPORT_DIRECTORY='reports/cucumber/merged'
    XC_TEST_ENVIRONMENT=

## Example of JIRA test execution report

![Test Report](images/test_report.png?raw=true "Test Report")

## Example of JIRA Gatling test execution report

![Test Report Gatling](images/test_report_gatling.png?raw=true "Test Report Gatling")
