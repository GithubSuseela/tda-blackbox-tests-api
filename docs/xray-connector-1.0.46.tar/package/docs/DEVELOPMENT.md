# xray-connector development

## xray-connector self-tests

Self-tests are provided in order to check xray-connector code changes against regressions.

### Test strategy

2 levels of tests are implemented:
- Component tests that check the connector's core functionality. These tests do no require any communication with XRay or Jira.
- End to end tests that cover the connector's communication with XRay. These tests are using the Jira `XRAY_BOY` project.

Component tests and end to end tests are implemented with **Cucumber**.

### Running the tests

You may run the connector integration tests with:

    $ npm run test:without-xray

End to end tests may be run with:

    $ npm run test:with-xray

### Runing Sonar checks

Sonar Quality gates can be checked locally using a SonarQube docker image.

To start Sonar locally, run:

    $ npm run sonar:start

To publish test coveragre information to the local Sonar container, run:

    $ npm run test:sonar

To stop the local Sonar container, run:

    $ npm run sonar:stop
