# Integration with Gradle

## Prerequisites

* A gradle project
* An npm configuration for artifactory, as described [here](../ARTIFACTORY.md)

## Set up

1. Add to your project (root directory):
    * [xray-connector.gradle](gradle/xray-connector.gradle) file
    * [xray-connector](gradle/xray-connector/) directory and the `package.json` file it contains

2. Update your build.gradle and add:
    * [gradle-node-plugin](https://github.com/node-gradle/gradle-node-plugin)
    > ```
    > ...
    > plugins {
    >    ...
    >    id "com.github.node-gradle.node" version "2.2.4"
    >    ...
    > }
    > 
    > node {
    >     // Version of node to use.
    >     version = '14.4.0'
    >
    >     // Version of npm to use.
    >     npmVersion = '6.14.4'
    >
    >     // If true, it will download node using above parameters.
    >     // If false, it will try to use globally installed node.
    >     download = true
    > }
    > ...
    >```
    * Apply [xray-connector.gradle](gradle/xray-connector.gradle) file
    > ```
    > ...
    > apply from: 'xray-connector.gradle'
    > ...
    >```

## Configuration

Following properties MUST be provided:
 * **xc.host**: Jira host (sample: jira.dt.renault.com)
 * **xc.login**: Jira user login
 * **xc.pwd**: Jira user password
 * **xc.test.key**: 'Test', 'Test Set' or 'Test Plan' key (sample: xc.testKey=TDPTF-403)
 * **xc.test.environment**: xray test execution environment

 **Note:** This properties can be put into `gradle.properties` file or by using `-P` command line arguments


## How to use - Without gradle.properties file

### Get features

```
./gradlew xcGetFeatures \
    -Pxc.host=<JIRA_HOST> \
    -Pxc.login=<JIRA_USER> \
    -Pxc.pwd=<JIRA_USER_PASSWORD> \
    -Pxc.test.key=<JIRA_TEST_PLAN_TO_LOAD>
```

**Note:** All features will be download into `src/test/resources/xray-connector/ACTIVE`

### Run your test
As you can choose your cucumber test implementation you just have to integrate it and run:

```
./gradlew test ...
```

You **MUST** :
* Get `.feature` files from `src/test/resources/xray-connector/` (see [Get features](#get-features) )
* Export cucumber results as `.json` files into `build/surefire-reports` directory

**Note:** When your `test` task ends, the `xcBuildReport` task is automatically executed and create a merged cucumber report into `build/surefire-reports/merged`


### Send report into JIRA 
```
./gradlew xcSendReport \
    -Pxc.host=<JIRA_HOST> \
    -Pxc.login=<JIRA_USER> \
    -Pxc.pwd=<JIRA_USER_PASSWORD> \
    -Pxc.test.key=<JIRA_TEST_PLAN_TO_FILL> \
    -Pxc.test.environment=<TEST_ENVIRONMENT>
```
