# Integrating xray-connector with your project

## Declaring xray-connector in your project dependencies

Once you have installed and configured xray-connector, you may want to integrate it within your project repository.

If your project is already using npm modules hosted on artifactory, this is a no-brainer: you can simply add xray-connector as a dependency in your `package.json`.

On the other hand, if this is not the case and you don't want to go through the hassle of all the team having to upate their npm configuration to declare the artifactory repository, you may as well install xray-connector globally with:

```bash
$ npm install -g @rd/xray-connector
```
and therefore not include it in your project's dependencies.

In this case, you will have to handle its installation specifically in your CI pipeline. An example for this is provided in [here](GITLABCI.md).

## Setting up your workflow in package.json

Out of the different steps that take place when using xray-connector (retrieve tests, run tests, build report, send report), the test execution steps involves your Test Automation Framework.

To orchestrate the interactions between xray-connector and your Test Automation Framework and possibly group them all within a single command, you may use scripts in your `package.json`, as illustrated here:


```json
  "scripts": {
    "xc:clean:features": "rm -rf downloaded-features/*",
    "xc:get-features": "npx xray-get-features",
    "xc:clean:reports:features": "rm -rf reports/cucumber/*",
    "xc:test-features": "npm run xc:clean:reports:features; npx cypress run --spec \"downloaded-features/ACTIVE/*\"",
    "xc:clean:reports:merged": "rm -rf reports/cucumber/merged/*",
    "xc:build-report": "npm run xc:clean:reports:merged; npx xray-build-report",
    "xc:send-report": "npx xray-send-report",
    "xc:all": "npm run xc:get-features; npm run xc:test-features; npm run xc:build-report; npm run xc:send-report"
  },
```

Note that the paths declared in the scripts need to be consistent with xray-connector configuration settings:

- `downloaded-features` should be the same as the `XC_FEATURES_DOWNLOAD_DIRECTORY` environment variable
- `reports/cucumber` should be the same as the `XC_FEATURES_REPORT_DIRECTORY` environment variable
- `reports/cucumber/merged` should be the same as the `XC_MERGED_REPORT_DIRECTORY` environment variable
