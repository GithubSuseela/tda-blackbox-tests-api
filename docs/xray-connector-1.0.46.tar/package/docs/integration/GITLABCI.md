# Integration with Gitlab CI

To integrate xray-connector in your CI, you will need to install it in the environment that executes your automated tests.

Assuming you are using a docker container as an environment for your automated tests, you will need to install xray-connector in this container.

To do so, you may add the following section at the end of your container Dockerfile:

```Dockerfile
# Install xray-connector
ARG ARTIFACTORY_USERNAME
ARG ARTIFACTORY_TOKEN
ARG PROXY_HOST
ARG PROXY_PORT

RUN echo "ARTIFACTORY_USERNAME=${ARTIFACTORY_USERNAME}"
RUN echo "PROXY=${PROXY_HOST}:${PROXY_PORT}"

# Generating .npmrc by calling artifactory auth API
RUN apt-get install -y curl
RUN curl -x ${PROXY_HOST}:${PROXY_PORT} -u $ARTIFACTORY_USERNAME:$ARTIFACTORY_TOKEN https://artifactory.dt.renault.com/artifactory/api/npm/npm-renault/auth/rd > .npmrc
RUN npm config set proxy http://${PROXY_HOST}:${PROXY_PORT}
RUN npm config set https-proxy http://${PROXY_HOST}:${PROXY_PORT}
RUN cat .npmrc | sed "s/:_password=.*$/:_password= *** HIDDEN ***/"

RUN npm install @rd/xray-connector --save-dev
```

The four variables `ARTIFACTORY_USERNAME`, `ARTIFACTORY_TOKEN`, `PROXY_HOST` and `PROXY_PORT` will have to be passed to the `docker build` command when building your container.

Here is an example of a `gitlab-ci.yml` file that does this:

```
test_e2e:
 <<: *tpl_ci
 stage: test
 only:
  - integration
 script:
   - docker pull ${IMAGE_BASE_DTR}
   - docker build --build-arg image_base=${IMAGE_BASE_DTR} --build-arg PROXY_HOST=${PROXY_HOST} --build-arg PROXY_PORT=${PROXY_PORT} --build-arg ARTIFACTORY_USERNAME=${ARTIFACTORY_USERNAME} --build-arg ARTIFACTORY_TOKEN=${ARTIFACTORY_TOKEN} --target teste2e -t teste2e -f dockerfiles/ci/Dockerfile.cypress .
   - docker rm -fv teste2e || true
   - docker run -e JIRA_XRAY_LOGIN=${JIRA_XRAY_LOGIN} -e JIRA_XRAY_PASSWORD=${JIRA_XRAY_PASSWORD} --name teste2e teste2e run xray:all
```

This configuration builds the automated tests docker container and runs the tests.

Note that the four variables mentioned above should not be hard-coded in any of your files, but rather declared as secrets in your project Gitlabee environment.
