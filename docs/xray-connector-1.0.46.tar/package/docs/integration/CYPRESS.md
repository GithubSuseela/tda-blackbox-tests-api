# Integration with Cypress

To configure xray-connector with Cypress, you will need to match xray-connector environment variables with your Cypress setup.

You will also need to make sure Cypress is properly configured for Cucumber tests execution.

## Configuring Cypress for Cucumber tests execution

One way of configuring Cypress for Cucumber tests execution is to use [cypress-cucumber-preprocessor](https://www.npmjs.com/package/cypress-cucumber-preprocessor).

Make sure your `package.json` contains the following section:

```json
  "cypress-cucumber-preprocessor": {
    "nonGlobalStepDefinitions": false,
    "step_definitions": "cypress/support/step_definitions/",
    "cucumberJson": {
      "generate": true,
      "outputFolder": "cypress/reports/cucumber",
      "filePrefix": "",
      "fileSuffix": ""
    }
```

Notes:

- The steps definition must be global for all features, hence the `nonGlobalStepDefinitions` parameter value
- `step_definitions` is the directory in which the steps implementation should be located
- The `generate` attribute of `cucumberJson` must be set to `true` so that JSON reports are generated during features test execution
- `outputFolder` is the directory in which the features test execution reports will be located

## Environment variables

Make sure the xray-connector environment variables you have defined are consistent with your Cypress set up:

| Variable                       | Cypress                                                                                                               | Example                                 |
| ------------------------------ | --------------------------------------------------------------------------------------------------------------------- | --------------------------------------- |
| XC_FEATURES_DOWNLOAD_DIRECTORY | Should be a subdirectory of your Cypress integration folder                                                         | cypress/integration/downloaded-features |
| XC_FEATURES_REPORT_DIRECTORY   | Should be the same as the `cucumberJson.outputFolder` attribute of your `cypress-cucumber-preprocessor` configuration | cypress/reports/cucumber                |

In addition, make sure that `XC_MERGED_REPORT_DIRECTORY` is different from `XC_FEATURES_REPORT_DIRECTORY`.

