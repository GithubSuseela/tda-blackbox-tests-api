# xray-connector vs. using Xray REST API

The main synchronisation features provided by xray-connector are available through Xray API.

It is therefore entirely possible to implement this synchronisation without using xray-connector, as explained [here](https://confluence.xpand-it.com/display/XRAY/Integration+with+GitLab).

xray-connector, though, offers several advantages:
* an integrated solution that saves you from the hassle of glueing all the pieces together
* additional report processing features that will help you convert reports from your test automation frameworks into Xray compatible reports

# Features provided by both JIRA Xray API and xray-connector

* Tests distributed in feature files based on JIRA Epics
* Include Xray pre-conditions in feature files
* Include Xray tests Scenario in feature files
* Include Xray tests Scenario Outlines in feature files
* Include Xray tests labels in feature files as tags
* Update test execution status in JIRA/Xray based on a JSON report file

# Features provided exclusively by xray-connector

* Merge JSON Cucumber compatible test execution reports into a single Xray compatible JSON test execution report
* Convert a Gatling test execution report into a Xray compatible JSON test execution report
* Retrieve and parse Test plan description (for instance to use as configuration for Gatling tests)
