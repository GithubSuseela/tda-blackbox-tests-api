# xray-connector commands

**NOTE**:
before running xray-connector command, you should make sure you have configured it properly, as described [here](VARIABLES.md).

From the command line, you may run:

 * To retrieve tests from Xray and generate feature files:
```bash
$ npx xray-get-features
````

 * To publish a test execution report back to Xray:
```bash
$ npx xray-send-report
```

Additionally, depending on your test automation framework, you may want to use:

* To aggregate several JSON test execution reports into one, for instance if you are using Cypress:
```bash
$ npx xray-build-report
```

* To generate an Xray compatible report from Gatling reports:
```bash
$ npx xray-build-gatling-report 
```

**NOTE**:
These last commands should be run **before** publishing the report with `xray-sent-report`.
