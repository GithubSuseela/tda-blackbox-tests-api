# Contributing

Please take a moment to review this document in order to make the contribution process easy and effective for everyone involved.

The issue tracker is the preferred channel for bug reports, features requests and submitting merge requests.

## Bug reports

A bug is a demonstrable problem that is caused by the code in the repository. Good bug reports are extremely helpful.

Before creating a bug report, check if it has not already been created by others.<br>
Prepare a description containing the steps to reproduce the bug.

## Feature requests

Feature requests are welcome.<br>
Before proposing a feature, find out whether your idea fits with the scope of the project.<br>
If a proposal is pertinent, try to explain the main idea, its requirements, its users and its context as much as possible.<br>
A good understanding of the requested feature may be crucial for the acceptance of the proposal by the community around this project.

## Merge requests

Good merge requests are a fantastic help.<br>
It is the step where you submit patches to this repository.<br>
To prevent any frustration, you should make sure to open an issue to discuss any new features before working on it.<br>
This will prevent you from wasting time on a feature the maintainers doesn't see fit for the project scope.<br>
In any case, a merge request should remain focused in scope and avoid containing unrelated commits.

The documentation should always be updated based on your changes. In particular, make sure any new feature you add is properly documented.<br>
Keep in mind that `xray-connector` users are not expected to read its code.

### How to do it?

1. Clone the repository

```
git clone https://gitlabee.dt.renault.com/shared/components/quality/xray-connector.git .
```

2. If you cloned a while ago, get the latest changes from upstream.

```
git checkout master
git pull origin master
```

3. Create a fixture (fix), refactoring (refact) or feature (feat) :

```
git checkout -b fix|refact|feat-name
```

Alternatively, you may create a branch/merge request from the Gitlab issue.

4. Commit your changes in logical chunks.<br>Please mention the issue(s) addressed in your commit message.<br>Don't forget to write/update tests concerning the evolution proposed (more information on `xray-connector` tests can be found [here](docs/DEVELOPMENT.md)).

```
git commit -m '✨ (module) message (covers issue #x)'
```

5. Push your changes

```
git push origin <your-branch-name>
```

6. Open a merge request with a clear title and description.
