/* eslint-disable @typescript-eslint/restrict-template-expressions */

function print(message: string) {
  console.log(message); // NOSONAR
}

if (process.env.DEBUG_PROXY || process.env.XC_DEBUG_PROXY) {
  print('======= xray-connector PROXY environment variables ======');
  print(`no_proxy         = ${process.env.no_proxy}`);
  print(`NO_PROXY         = ${process.env.NO_PROXY}`);
  print(`JIRA_XRAY_PROXY  = ${process.env.JIRA_XRAY_PROXY}`);
  print(`https_proxy      = ${process.env.https_proxy}`);
  print(`HTTPS_PROXY      = ${process.env.HTTPS_PROXY}`);
  print(`http_proxy       = ${process.env.http_proxy}`);
  print(`HTTP_PROXY       = ${process.env.HTTP_PROXY}`);
  print('------- Variables not used --------------------------');
  print(`HTTPS_PROXY_URL  = ${process.env.HTTPS_PROXY_URL}`);
  print(`HTTPS_PROXY_HOST = ${process.env.HTTPS_PROXY_HOST}`);
  print(`HTTPS_PROXY_PORT = ${process.env.HTTPS_PROXY_PORT}`);
  print(`HTTP_PROXY_URL   = ${process.env.HTTP_PROXY_URL}`);
  print(`HTTP_PROXY_HOST  = ${process.env.HTTP_PROXY_HOST}`);
  print(`HTTP_PROXY_PORT  = ${process.env.HTTP_PROXY_PORT}`);
  print('=====================================================');
}

function getUrlProxyFromEnv(url: string): { msg: string; proxyUrl: string | undefined } {
  let msg: string;
  let proxyUrl: string | undefined;

  const noProxy = process.env.no_proxy || process.env.NO_PROXY;
  if (`,${noProxy},`.includes(new URL(url).hostname)) {
    msg = `host in no_proxy/NO_PROXY (${noProxy})`;
    proxyUrl = undefined;
    return { msg, proxyUrl };
  }

  if (process.env.JIRA_XRAY_PROXY) {
    msg = 'using JIRA_XRAY_PROXY';
    proxyUrl = process.env.JIRA_XRAY_PROXY;
    return { msg, proxyUrl };
  }

  if (process.env.https_proxy) {
    msg = 'using https_proxy';
    proxyUrl = process.env.https_proxy;
    return { msg, proxyUrl };
  }

  if (process.env.HTTPS_PROXY) {
    msg = 'using HTTPS_PROXY';
    proxyUrl = process.env.HTTPS_PROXY;
    return { msg, proxyUrl };
  }

  if (process.env.http_proxy) {
    msg = 'using http_proxy';
    proxyUrl = process.env.http_proxy;
    return { msg, proxyUrl };
  }

  if (process.env.HTTP_PROXY) {
    msg = 'using HTTP_PROXY';
    proxyUrl = process.env.HTTP_PROXY;
    return { msg, proxyUrl };
  }

  msg = 'no PROXY defined';
  proxyUrl = undefined;
  return { msg, proxyUrl };
}

export function getProxyForUrl(url: string): string | undefined {
  const { msg, proxyUrl } = getUrlProxyFromEnv(url);

  if (process.env.DEBUG_PROXY || process.env.XC_DEBUG_PROXY) {
    print(`- URL ${url.split('?').shift()}: ${msg} -> ${proxyUrl}`);
  }

  return proxyUrl;
}
