/* eslint-disable @typescript-eslint/no-explicit-any */

export function print(...args: any[]): void {
  console.log(...args); // NOSONAR
}
