export function unsetTestEnvironment(): void {
  delete process.env['XC_TEST_ENVIRONMENT'];
}
