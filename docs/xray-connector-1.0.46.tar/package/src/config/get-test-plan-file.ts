export function getTestPlanFile(): string {
  return process.env.XC_TEST_PLAN_FILE as string;
}
