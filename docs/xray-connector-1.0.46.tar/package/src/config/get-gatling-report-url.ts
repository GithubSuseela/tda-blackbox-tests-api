export function getGatlingReportUrl(): string {
  return process.env.XC_GATLING_REPORT_URL as string;
}
