export function setXrayDefaultTestPlanKey(testPlanKey: string): void {
  process.env.XC_DEFAULT_TEST_PLAN = testPlanKey;
}
