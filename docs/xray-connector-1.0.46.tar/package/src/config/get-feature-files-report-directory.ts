export function getFeatureFilesReportDirectory(): string {
  return (process.env.XC_FEATURES_REPORT_DIRECTORY as string) || 'reports/cucumber/features';
}
