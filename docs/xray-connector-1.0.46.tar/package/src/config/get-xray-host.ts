export function getXrayHost(): string {
  return (process.env.JIRA_XRAY_HOST as string) || 'jira.dt.renault.com';
}
