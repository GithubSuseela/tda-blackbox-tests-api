export function setMergedReportDirectory(mergedReportDirectory: string): void {
  process.env.XC_MERGED_REPORT_DIRECTORY = mergedReportDirectory;
}
