export function setTestFixVersions(testFixVersions: string): void {
  process.env.XC_TEST_FIX_VERSIONS = testFixVersions;
}
