export function getTestEnvironment(): string {
  return process.env.XC_TEST_ENVIRONMENT as string;
}
