export function setTestLabels(testLabels: string): void {
  process.env.XC_TEST_LABELS = testLabels;
}
