export function setTestPlanFile(testPlanFile: string): void {
  process.env.XC_TEST_PLAN_FILE = testPlanFile;
}
