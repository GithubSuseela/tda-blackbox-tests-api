export function getMergedReportDirectory(): string {
  return (process.env.XC_MERGED_REPORT_DIRECTORY as string) || 'reports/cucumber/merged';
}
