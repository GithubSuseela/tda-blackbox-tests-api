import { XrayFieldsIds } from '../types';
import { getXrayHost } from './get-xray-host';

export function getXrayFieldsIds(): XrayFieldsIds {
  if (getXrayHost().indexOf('jira.intra.renault.fr') !== -1) {
    // Ids for jira.intra.renault.fr
    return {
      testExecutionIssueTypeId: 10204,
      testExecutionTestPlansFieldId: 10226,
      testExecutionTestEnvironmentsFieldId: 10224,
    };
  } else {
    // Default for jira.dt.renault.com and (maybe) others
    return {
      testExecutionIssueTypeId: 10212,
      testExecutionTestPlansFieldId: 10268,
      testExecutionTestEnvironmentsFieldId: 10266,
    };
  }
}
