export function setGatlingSimulation(gatlingSimulation: string): void {
  process.env.XC_GATLING_SIMULATION = gatlingSimulation;
}
