export function setFeaturesDownloadDirectory(featureFilesDirectory: string): void {
  process.env.XC_FEATURES_DOWNLOAD_DIRECTORY = featureFilesDirectory;
}
