export function getGatlingSimulation(): string {
  return process.env.XC_GATLING_SIMULATION as string;
}
