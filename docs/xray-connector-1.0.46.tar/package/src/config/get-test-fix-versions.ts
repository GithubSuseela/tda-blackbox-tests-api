export function getTestFixVersions(): string {
  return process.env.XC_TEST_FIX_VERSIONS as string;
}
