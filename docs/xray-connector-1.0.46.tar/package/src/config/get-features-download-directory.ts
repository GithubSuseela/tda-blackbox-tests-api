export function getFeaturesDownloadDirectory(): string {
  return (process.env.XC_FEATURES_DOWNLOAD_DIRECTORY as string) || 'downloaded-features';
}
