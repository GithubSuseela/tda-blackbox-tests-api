export function getXrayDefaultTestPlanKey(): string {
  const defaultTestPlan: string = process.env.XC_DEFAULT_TEST_PLAN as string;

  if (defaultTestPlan == undefined || defaultTestPlan == '') {
    throw new Error("XC_DEFAULT_TEST_PLAN environment variable not defined. Won't be able to retrieve tests from Xray");
  } else {
    return defaultTestPlan;
  }
}
