import { Credentials } from '../types';

export function getXrayCredentials(): Credentials {
  const username: string = process.env.JIRA_XRAY_LOGIN as string;
  const password: string = (process.env.JIRA_XRAY_PASSWORD as string) || (process.env.JIRA_XRAY_PASSWD as string);
  const cookie: string = process.env.JIRA_XRAY_COOKIE as string;
  const token: string = process.env.JIRA_XRAY_TOKEN as string;

  if (cookie) {
    let error = 'Incorrect credentials information. ';
    error += 'JSESSIOID cookie support has been discontinued. ';
    error += 'Please unsed JIRA_XRAY_COOKIE environmen variable. ';
    throw new Error(error);
  }

  if (token === undefined && (username === undefined || password === undefined)) {
    let error = 'Missing credentials information. ';
    error += 'Either login & password or session id or token must be defined. ';
    error += `JIRA_XRAY_LOGIN=${username}, `;
    error += `JIRA_XRAY_PASSWORD=${password}, `;
    error += `JIRA_XRAY_TOKEN=${token as string}.`;
    throw new Error(error);
  }

  return {
    username,
    password,
    token,
  } as Credentials;
}
