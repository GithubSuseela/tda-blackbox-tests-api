export function setFeatureFilesReportsDirectory(featureFilesReportDirectory: string): void {
  process.env.XC_FEATURES_REPORT_DIRECTORY = featureFilesReportDirectory;
}
