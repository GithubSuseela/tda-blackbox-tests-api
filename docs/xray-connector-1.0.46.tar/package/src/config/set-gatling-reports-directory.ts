export function setGatlingReportsDirectory(gatlingReportsDirectory: string): void {
  process.env.XC_GATLING_REPORTS_DIRECTORY = gatlingReportsDirectory;
}
