export function setTestEnvironment(testEnvironment: string): void {
  process.env.XC_TEST_ENVIRONMENT = testEnvironment;
}
