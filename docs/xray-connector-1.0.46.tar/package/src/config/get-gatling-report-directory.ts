export function getGatlingReportsDirectory(): string {
  return process.env.XC_GATLING_REPORTS_DIRECTORY as string;
}
