export function getTestLabels(): string {
  return process.env.XC_TEST_LABELS as string;
}
