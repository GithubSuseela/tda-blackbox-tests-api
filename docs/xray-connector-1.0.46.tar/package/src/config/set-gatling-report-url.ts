export function setGatlingReportUrl(url: string): void {
  process.env.XC_GATLING_REPORT_URL = url;
}
