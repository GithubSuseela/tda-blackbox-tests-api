import { TestSimulationStep } from '.';

export class TestSimulation {
  public tag: string;

  public injectionSteps: TestSimulationStep[];

  constructor() {
    this.tag = '*';

    this.injectionSteps = [];
  }
}
