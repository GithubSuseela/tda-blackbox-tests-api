/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */

import { TestSimulation, TestSimulationStep } from '.';

export class TestPlan {
  public successfulRequestsPercent: number | undefined;
  public responseTimeMin: number | undefined;
  public responseTimeMax: number | undefined;
  public responseTimeMean: number | undefined;
  public responseTimeStdDev: number | undefined;
  public responseTimePercentile50th: number | undefined;
  public responseTimePercentile75th: number | undefined;
  public responseTimePercentile95th: number | undefined;
  public responseTimePercentile99th: number | undefined;
  public requestsPerSecond: number | undefined;

  public simulations: TestSimulation[];

  constructor() {
    this.successfulRequestsPercent = 100;
    this.responseTimeMin = undefined;
    this.responseTimeMax = undefined;
    this.responseTimeMean = undefined;
    this.responseTimeStdDev = undefined;
    this.responseTimePercentile50th = undefined;
    this.responseTimePercentile75th = undefined;
    this.responseTimePercentile95th = undefined;
    this.responseTimePercentile99th = undefined;
    this.requestsPerSecond = undefined;

    this.simulations = [];
  }

  public static fromXray(object: any): TestPlan {
    const testPlan: TestPlan = new TestPlan();

    const lines: string[] = (object.description || '').split(/[\r\n]+/);
    TestPlan.parseDescriptionLine(lines, testPlan);

    return testPlan;
  }

  private static parseDescriptionLine(lines: string[], testPlan: TestPlan) {
    let result: RegExpExecArray | null;

    // prettier-ignore
    lines.forEach((line: string) => { // NOSONAR
      line = line.trim();

      result = new RegExp('^ASSERT_RESPONSE_TIME_MIN=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimeMin = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_MAX=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimeMax = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_MEAN=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimeMean = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_STD_DEV=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimeStdDev = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_PERCENTILE_50TH=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimePercentile50th = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_PERCENTILE_75TH=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimePercentile75th = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_PERCENTILE_95TH=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimePercentile95th = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_RESPONSE_TIME_PERCENTILE_99TH=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.responseTimePercentile99th = parseInt(result[1], 10);
      }

      result = new RegExp('^ASSERT_REQUESTS_PER_SECOND=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        testPlan.requestsPerSecond = parseInt(result[1], 10);
      }

      result = new RegExp('^TAG=(\\S*)$').exec(line);
      if (result && result.length > 1) {
        const simulation: TestSimulation = new TestSimulation();

        simulation.tag = result[1];

        testPlan.simulations.push(simulation);
      }

      result = new RegExp('^INJECTION_PROFILE=(\\S*)$').exec(line);
      if (result && result.length > 1) {
        const simulation: TestSimulation = TestPlan.getSimulation(testPlan);
        const step: TestSimulationStep = new TestSimulationStep();

        step.injectionProfile = result[1];

        simulation.injectionSteps.push(step);
      }

      result = new RegExp('^USERS=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        const simulation: TestSimulation = TestPlan.getSimulation(testPlan);
        const step: TestSimulationStep = TestPlan.getStep(simulation);

        step.users = parseInt(result[1], 10);
      }

      result = new RegExp('^DURATION=(\\d*)$').exec(line);
      if (result && result.length > 1) {
        const simulation: TestSimulation = TestPlan.getSimulation(testPlan);
        const step: TestSimulationStep = TestPlan.getStep(simulation);

        step.duration = parseInt(result[1], 10);
      }
    });
  }

  private static getSimulation(testPlan: TestPlan) {
    if (testPlan.simulations.length > 0) {
      return testPlan.simulations[testPlan.simulations.length - 1];
    }

    return new TestSimulation();
  }

  private static getStep(simulation: TestSimulation | null) {
    if (simulation && simulation.injectionSteps.length > 0) {
      return simulation.injectionSteps[simulation.injectionSteps.length - 1];
    }

    return new TestSimulationStep();
  }
}
