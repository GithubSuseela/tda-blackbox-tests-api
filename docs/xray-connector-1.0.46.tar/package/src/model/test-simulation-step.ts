export class TestSimulationStep {
  public injectionProfile: string;
  public users: number;
  public duration: number;

  constructor() {
    this.injectionProfile = '';
    this.users = 1;
    this.duration = 0;
  }
}
