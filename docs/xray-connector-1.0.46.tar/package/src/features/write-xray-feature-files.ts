/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */

import fs from 'fs';
import unzipper from 'unzipper';

export async function writeXrayFeatureFiles(zippedFeatureFilesContent: any, basedir: string): Promise<void> {
  const featureFile: string = basedir + '/ACTIVE.zip';

  // Save file
  fs.writeFileSync(featureFile, zippedFeatureFilesContent, 'binary');

  // Unzip file
  await fs
    .createReadStream(featureFile)
    .pipe(unzipper.Extract({ path: basedir + '/ACTIVE' }))
    .promise();

  // Remove zip file
  fs.unlinkSync(featureFile);
}
