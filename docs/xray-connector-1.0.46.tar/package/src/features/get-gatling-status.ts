/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */

import fs from 'fs';
import path from 'path';

import { getGatlingReportsDirectory, getGatlingSimulation } from '../config';

export class GatlingAssertion {
  public status: boolean;
  public message: string;

  constructor(status: boolean, message: string) {
    this.status = status;
    this.message = message;
  }
}

export class GatlingStatus {
  public status: string;
  public assertions: GatlingAssertion[];

  constructor(status: string, assertions: GatlingAssertion[]) {
    this.status = status;
    this.assertions = assertions;
  }
}

/**
 * Parse global status from assertions.json
 *
 * assertions.json is expected to be:
 *
 * {
 *   "assertions": [
 *     {
 *       "message": "xxx",
 *       "result": true | false
 *     }, ...
 *   ]
 * }
 */

function parseIntFromString(string: string, prefix: string): number {
  return parseInt(string.substring(prefix.length + 1), 10);
}

export function getGatlingStatus(): GatlingStatus {
  const prefix = getGatlingSimulation().toLowerCase();

  const folder: string | undefined = fs
    .readdirSync(getGatlingReportsDirectory())
    .filter((name: string) => name.startsWith(prefix))
    .sort((a: string, b: string) => parseIntFromString(b, prefix) - parseIntFromString(a, prefix))
    .shift();

  if (!folder) {
    return new GatlingStatus('aborted', []);
  }

  const assertionFile: string = path.join(getGatlingReportsDirectory(), folder, 'js', 'assertions.json');
  if (!fs.existsSync(assertionFile)) {
    return new GatlingStatus('aborted', []);
  }

  const assertionJson: any = JSON.parse(fs.readFileSync(assertionFile).toString('utf8'));
  const assertions = assertionJson['assertions'] || [];
  const reducedStatus = assertions.reduce((status: boolean, assertion: any) => status && assertion['result'], true);
  return new GatlingStatus(
    reducedStatus ? 'passed' : 'failed',
    assertions.map((assertion: any) => new GatlingAssertion(assertion['result'], assertion['message'])),
  );
}
