/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-var-requires */

const proxy = require('node-global-proxy').default; // NOSONAR

import { getXrayHost } from '../config';
import { getProxyForUrl } from '../utils';

export function setProxy(): void {
  const httpsProxy = getProxyForUrl(`https://${getXrayHost()}`);
  if (httpsProxy) {
    proxy.setConfig(httpsProxy);
    proxy.start();
  }
}
