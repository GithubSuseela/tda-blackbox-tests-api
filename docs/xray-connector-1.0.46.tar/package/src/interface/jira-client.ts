import JiraApiWithXray from 'jira-client-xray';
import { JiraClientOptions } from '../types';
import { getXrayHost, getXrayCredentials } from '../config';

let jira: any;

function initJiraClient() {
  const credentials = getXrayCredentials();
  const jiraClientOptions: JiraClientOptions = {
    strictSSL: true,
    protocol: 'https',
    host: getXrayHost(),
    base: '',
    xrayVersion: '1.0',
  };
  if (credentials.token) {
    jiraClientOptions.bearer = credentials.token;
  } else {
    jiraClientOptions.username = credentials.username;
    jiraClientOptions.password = credentials.password;
  }
  return new JiraApiWithXray(jiraClientOptions);
}

export function getJiraClient() {
  return jira || initJiraClient();
}

export function destroyJiraClient() {
  jira = undefined;
}
