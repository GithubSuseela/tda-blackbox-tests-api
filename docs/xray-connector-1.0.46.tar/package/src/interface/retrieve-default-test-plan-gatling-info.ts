import { TestPlan } from '../model';
import { getXrayDefaultTestPlanKey } from '../config';
import { print } from '../utils';
import { getJiraClient } from './jira-client';

/**
 * Retrieves the default (Gatling) test plan information from Xray
 */
export async function retrieveDefaultTestPlanGatlingInfo() {
  try {
    const jira = getJiraClient();
    const issue: any = await jira.findIssue(getXrayDefaultTestPlanKey());
    return TestPlan.fromXray(issue.fields);
  } catch (error) {
    print(`!!! Failed to retrieve issue ${getXrayDefaultTestPlanKey()} from JIRA !!!`);
    print(error);
    throw new Error((error as Error).message);
  }
}
