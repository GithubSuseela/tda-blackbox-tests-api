import { getXrayDefaultTestPlanKey } from '../config';
import { getJiraClient } from './jira-client';

/**
 * Export feature files corresponding to the default test plan from Xray
 */
export function retrieveDefaultTestPlanFeatureFiles() {
  return getFeaturesByKeys([getXrayDefaultTestPlanKey()]);
}

// https://confluence.xpand-it.com/display/public/XRAY/Exporting+Cucumber+Tests+-+REST

function getFeaturesByKeys(keys: string[]) {
  const jira = getJiraClient();
  const header = jira.makeRequestHeader(
    jira.makeXrayUri({
      pathname: `/export/test?keys=${keys.join(';')}&fz=true`,
    }),
  );
  header.method = 'GET';
  header.json = false;
  header.encoding = null;
  return jira.doRequest(header);
}
