import { buildExecutionInfo } from './build-execution-info';
import { getJiraClient } from './jira-client';

// https://confluence.xpand-it.com/display/public/XRAY/Import+Execution+Results+-+REST

/**
 * Creates an execution for test plan in Xray
 */
export function createTestPlanExecution(
  summary: string,
  description: string,
  results: JSON,
  testPlanKey: string,
  testLabels: string,
  testFixVersions: string,
  testEnvironment: string,
) {
  const jira = getJiraClient();

  const header = jira.makeRequestHeader(
    jira.makeXrayUri({
      pathname: '/import/execution/cucumber/multipart',
    }),
  );

  header.method = 'POST';

  const info = JSON.stringify(
    buildExecutionInfo(
      summary,
      description,
      testPlanKey,
      testLabels ? testLabels.split(',') : [],
      testFixVersions ? testFixVersions.split(',') : [],
      testEnvironment ? [testEnvironment] : undefined,
    ),
  );

  const result = {
    value: JSON.stringify(results),
    options: {
      filename: 'merged-output.json',
      contentType: 'application/json',
    },
  };

  const formData = {
    info,
    result,
  };
  header.formData = formData;

  return jira.doRequest(header);
}
