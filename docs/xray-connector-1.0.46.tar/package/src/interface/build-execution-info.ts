// https://wanago.io/2019/03/18/node-js-typescript-6-sending-http-requests-understanding-multipart-form-data/

import { getXrayFieldsIds } from '../config';
import { XrayFieldsIds } from '../types';

export function buildExecutionInfo(
  summary: string,
  description: string,
  testPlanKey: string,
  labels?: string[],
  fixVersions?: string[],
  testEnvironments?: string[],
) {
  const fieldsIds: XrayFieldsIds = getXrayFieldsIds();
  const testExecutionTestEnvionmentsFieldId = 'customfield_' + fieldsIds.testExecutionTestEnvironmentsFieldId;
  const testExecutionTestPlansFieldId = 'customfield_' + fieldsIds.testExecutionTestPlansFieldId;
  const projectKey: string = testPlanKey.split('-')[0];
  // prettier-ignore
  const info: any = { // NOSONAR
      fields: {
        summary,
        description,
        labels,
        project: {
          key: projectKey,
        },
        issuetype: {
          id: '' + fieldsIds.testExecutionIssueTypeId,
        },
      },
    };
  info.fields[testExecutionTestEnvionmentsFieldId] = [] as string[];
  info.fields[testExecutionTestPlansFieldId] = [testPlanKey];
  // Add environments if provided
  if (testEnvironments && testEnvironments.length !== 0) {
    info.fields[testExecutionTestEnvionmentsFieldId] = testEnvironments;
  }
  // Add fix version if provided
  if (fixVersions && fixVersions.length !== 0) {
    info.fields.fixVersions = fixVersions;
  }
  return info;
}
