declare module 'jira-client-xray';
