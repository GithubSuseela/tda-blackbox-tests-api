declare module 'multiple-cucumber-html-reporter';
