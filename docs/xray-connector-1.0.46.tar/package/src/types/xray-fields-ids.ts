export type XrayFieldsIds = {
  testExecutionIssueTypeId: number;
  testExecutionTestPlansFieldId: number;
  testExecutionTestEnvironmentsFieldId: number;
};
