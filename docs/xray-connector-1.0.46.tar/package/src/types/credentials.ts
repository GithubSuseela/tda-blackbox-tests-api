export type Credentials = {
  username: string;
  password: string;
  token: string;
};
