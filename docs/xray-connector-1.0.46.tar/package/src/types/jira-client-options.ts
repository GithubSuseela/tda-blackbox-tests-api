export type JiraClientOptions = {
  strictSSL: boolean;
  protocol: string;
  host: string;
  base: string;
  xrayVersion: string;
  username?: string;
  password?: string;
  bearer?: string;
};
