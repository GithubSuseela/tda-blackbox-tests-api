const HTTP_BAD_REQUEST_ERROR_CODE = 400;
const HTTP_UNAUTHORIZED_ERROR_CODE = 401;
const HTTP_FORBIDDEN_ERROR_CODE = 401;

// prettier-ignore
export function analyseXrayError(error: any) { // NOSONAR
  // console.log(JSON.stringify(error, null, 4));
  let analysis: string;
  analysis = '\n';
  if (error.statusCode) {
    const options = error.options || error.response.options;
    if (options.method && options.uri) {
      analysis += `Error ${error.statusCode} while calling ${options.method} ${options.uri}.\n`;
      analysis += '\n';
    }
  }
  if (error.error && error.error.error) {
    analysis += 'Error message: ';
    analysis += error.error.error + '\n';
    analysis += '\n';
  }
  if (error.statusCode) {
    switch (error.statusCode) {
      case HTTP_UNAUTHORIZED_ERROR_CODE:
        analysis += 'Unauthorized error: please check JIRA_XRAY_LOGIN, JIRA_XRAY_PASSWORD and JIRA_XRAY_TOKEN.\n';
        analysis += 'In particular, make sure you are not using a password as a token or vice versa.\n';
        break;
      case HTTP_FORBIDDEN_ERROR_CODE:
        analysis += 'Forbidden error: please make sure your JIRA/Xray account has been not been locked.\n';
        analysis +=
          'In particular, this might be the case if there have been too many failed authentication attempts with this account.\n';
        break;
      case HTTP_BAD_REQUEST_ERROR_CODE:
        analysis += 'Bad request error: please check JIRA_XRAY_HOST and XC_DEFAULT_TEST_PLAN.\n';
        analysis +=
          'In particular, your test plan ID might not correspond to an existing test plan or to a test plan your JIRA/Xray account has access to.\n';
        break;
      default:
        analysis += 'Unknown error: please update xray-connector once error has been analyzed and understood.\n';
        break;
    }
  }
  return analysis;
}
