/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */

import report from 'multiple-cucumber-html-reporter';

import { getFeatureFilesReportDirectory, getMergedReportDirectory } from '../config';

export function mergeReports(): void {
  report.generate({
    jsonDir: getFeatureFilesReportDirectory(),
    reportPath: getMergedReportDirectory(),
    saveCollectedJSON: true,
    disableLog: true,
  });
}
