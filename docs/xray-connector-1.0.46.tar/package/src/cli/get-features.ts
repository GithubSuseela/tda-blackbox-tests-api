import fs from 'fs';

import { getXrayDefaultTestPlanKey, getFeaturesDownloadDirectory, getTestPlanFile } from '../config';
import { writeXrayFeatureFiles } from '../features';
import { retrieveDefaultTestPlanFeatureFiles, retrieveDefaultTestPlanGatlingInfo } from '../interface';
import { TestPlan } from '../model';
import { print } from '../utils';

import { setProxy } from '../interface/set-proxy';
import { analyseXrayError } from './analyse-xray-error';

export async function getFeatures(): Promise<void> {
  const featuresDownloadDirectory: string = getFeaturesDownloadDirectory();

  // Create the features download directory if needed
  if (!fs.existsSync(featuresDownloadDirectory)) {
    fs.mkdirSync(featuresDownloadDirectory, { recursive: true });
  }

  const testPlanFile: string = getTestPlanFile();
  if (testPlanFile) {
    let testPlan: TestPlan;
    try {
      testPlan = await retrieveDefaultTestPlanGatlingInfo();
    } catch (error) {
      throw new Error('Failed to retrieve test plan from Xray.');
    }
    try {
      const replacer = null;
      const space = 2;
      fs.writeFileSync(testPlanFile, JSON.stringify(testPlan, replacer, space));
    } catch (error) {
      throw new Error(`Failed to write test plan to ${testPlanFile}.`);
    }
  }

  let zippedFeatureFilesContent;
  try {
    zippedFeatureFilesContent = await retrieveDefaultTestPlanFeatureFiles();
  } catch (error) {
    throw new Error('Failed to download feature files from Xray.\n' + analyseXrayError(error));
  }

  try {
    await writeXrayFeatureFiles(zippedFeatureFilesContent, featuresDownloadDirectory);
  } catch (error) {
    throw new Error(`Failed to save feature files in ${featuresDownloadDirectory}.`);
  }
}

export async function getFeaturesWrapper(logOutput = true): Promise<void> {
  setProxy();
  await getFeatures();
  let output = '';
  output += 'Feature files for test plan ';
  output += getXrayDefaultTestPlanKey();
  output += ' successfully created in ';
  output += getFeaturesDownloadDirectory();
  output += '.';
  if (logOutput) {
    print(output);
  }
}
