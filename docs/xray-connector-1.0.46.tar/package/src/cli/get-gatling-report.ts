import fs from 'fs';
import path from 'path';

import { getFeaturesDownloadDirectory, getMergedReportDirectory } from '../config';
import { GatlingStatus, getGatlingStatus } from '../features';

export function getGatlingReport(): void {
  const mergedReportDirectory: string = getMergedReportDirectory();

  // Create the merged report directory if needed
  if (!fs.existsSync(mergedReportDirectory)) {
    fs.mkdirSync(mergedReportDirectory, { recursive: true });
  }

  generateReport(getTests(), getGatlingStatus());
}

/**
 * Get Xray tests from features
 * Tests are expected to contain a line with @<JIRA_PROJECT>-<TEST_ID>
 */

function getTests(): string[] {
  const featuresFolder: string = path.join(getFeaturesDownloadDirectory(), 'ACTIVE');
  const tests: string[] = [];

  if (fs.existsSync(featuresFolder)) {
    fs.readdirSync(featuresFolder)
      .filter((name: string) => name.endsWith('.feature'))
      .forEach((feature: string) => {
        fs.readFileSync(path.join(featuresFolder, feature))
          .toString('utf8')
          .split(/\r?\n/)
          .forEach((line: string) => {
            const result: RegExpExecArray | null = new RegExp('@(\\S*) ').exec(line);
            if (result && result.length > 1) {
              tests.push('@' + result[1].trim());
            }
          });
      });
  }

  return tests;
}

/**
 * Generate merged-output.json
 *
 * A report file is (minimally) expected to be:
 * [
 *   {
 *     "elements": [
 *       {
 *         "id": "xxx",
 *         "name": "xxx",
 *         "description": "xxx",
 *         "type": "scenario",
 *         "keyword": "Scenario",
 *         "steps": [
 *           {
 *             "name": "xxx",
 *             "result": {
 *               "status": "passed" | "failed"
 *             }
 *           }, ...
 *         ],
 *         "keyword": "Given | When | Then ",
 *         "tags": [ { "name": "@xxx-yyyy" } ]
 *       }, ...
 *     ]
 *   }
 * ]
 */

function generateReport(tests: string[], gatlingStatus: GatlingStatus): void {
  const mergedReportDirectory: string = getMergedReportDirectory();

  fs.writeFileSync(
    path.join(mergedReportDirectory, 'merged-output.json'),
    JSON.stringify([
      {
        elements: tests.map((test: string) => {
          return {
            id: test,
            name: test,
            description: '',
            type: 'scenario',
            keyword: 'Scenario',
            steps: [
              {
                name: test,
                result: { status: gatlingStatus.status },
                keyword: '',
              },
            ],
            tags: [{ name: test }],
          };
        }),
      },
    ]),
  );
}
