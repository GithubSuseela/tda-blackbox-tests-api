#!/bin/sh

echo "registry = https://artifactory.dt.renault.com/artifactory/api/npm/npm-renault-local/" > .npmrc
wget https://${ARTIFACTORY_USERNAME}:${ARTIFACTORY_TOKEN}@artifactory.dt.renault.com/artifactory/api/npm/auth -O auth -Y off
cat auth >> .npmrc

npm config fix

npm -v
