module.exports = {
  default: {
    require: ['test/step-definitions/**/*.ts'],
    requireModule: ['ts-node/register', 'dotenv/config', 'source-map-support/register'],
    format: ['@cucumber/pretty-formatter', ['json', 'reports/cucumber/features/cucumber.json']],
  },
};
