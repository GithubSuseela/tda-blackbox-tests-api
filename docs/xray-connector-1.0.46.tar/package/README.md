# xray-connector

xray-connector provides a mean to synchronize tests between Xray and a Test Automation Framework (for example Cypress).

It supports a transversal test management / test execution / test reporting process in which:

* automated tests are defined in JIRA/Xray using the GHERKIN syntax
* tests are automatically retrieved from JIRA/Xray and executed by the Test Automation Framework
* tests execution results are pushed back to JIRA/Xray by The Test Automation Framework, for analysis and reporting

## ✨Features

xray-connector provides the following features:

- retrieve test cases from JIRA/Xray as feature files
- publish test execution results back to JIRA/Xray
- merge separate, feature-based, tests execution reports into one for publication in JIRA/Xray
- convert Gatling test execution reports into JIRA/Xray compatible reports

It supports test execution with Cypress, Gatling, Karate, ...

## 🔑 Prerequisites

To run xray-connector, you will need:

* a JIRA account with api access to your project.
Please check the [QA chapter site](https://grouperenault.sharepoint.com/sites/QAchapter/SitePages/Reporting-to-JIRA--process-to-get-JIRA-accounts.aspx) or liaise with us on [teams](https://teams.microsoft.com/l/channel/19%3acb031a8fa52f43b8b0eb1088786509ab%40thread.tacv2/%255BAssets%255D%2520xray-connector?groupId=65198de9-8ac1-44cf-b55d-f2ffc1893b92&tenantId=d6b0bbee-7cd9-4d60-bce6-4a67b543e2ae) to get the necessary information.
* an Xray test plan with associated tests defined in your JIRA project.
Only tests with type **Cucumber** will be taken into account.

## ⚙️ Quick setup (Node environment)

If you are working in a **NodeJS** environment, the following steps will have your ready to use xray-connector in a few minutes.

- First, [configure npm to use artifactory](/docs/ARTIFACTORY.md)
- Then, install xray-connector as a dependency in your projet:

```bash
$ npm install --save @rd/xray-connector
```

- Last, set xray-connector minimum environment variables:

If your JIRA account has been provided to you with a password:

```bash
$ export JIRA_XRAY_LOGIN=<JIRA account login>
$ export JIRA_XRAY_PASSWORD=<JIRA account password>
$ export XC_DEFAULT_TEST_PLAN=<Your Xray reference test plan key>
```

If your JIRA account has been provided to you with a token:

```bash
$ export JIRA_XRAY_TOKEN=<JIRA account token>
$ export XC_DEFAULT_TEST_PLAN=<Your Xray reference test plan key>
```

If your project is hosted on the intra JIRA server rather than on the dt JIRA server, you will also need to set the following additional environment variable:

```bash
$ export JIRA_XRAY_HOST=jira.intra.renault.fr
```

- And voilà ! You should now be able to retrieve feature files from Xray using the following command:

```bash
$ npx xray-get-features
```

## ⚙️ Setup in a Java environment

If you are working in a **Java** environment, please refer to the [Gradle integration](docs/integration/GRADLE.md) page.

## ⚙️ Proxy configuration

xray-connector will use the following environment variables to determine which proxy to use to connect to Xray, in this order:

1. `JIRA_XRAY_PROXY`
2. `https_proxy`
3. `HTTPS_PROXY`
4. `http_proxy`
5. `HTTP_PROXY`

Other PROXY environment variables such as `HTTP_PROXY_URL`, `HTTP_PROXY_PORT`... will be ignored.

No proxy will be used for URLs with a hostname present in the `no_proxy`or `NO_PROXY` environment variables (exact match only).

If you need to investigate proxy issues, set the `DEBUG_PROXY` or `XC_DEBUG_PROXY` environment variable to any value.

Proxy configuration and usage information will then be logged on the terminal output.

If you are using a proxy in a **NodeJS** environment, please make sure you use node version > 10.

## 📖 Going further

Now you've set up xray-connector, you may want to dig deeper into the following topics:

* [How does xray-connector work?](docs/HOW_DOES_IT_WORK.md)
* [What are the different xray-connector configuration options?](docs/VARIABLES.md)
* [What are the different xray-connector commands?](docs/COMMANDS.md)
* [How to configure xray-connector for my test automation framework?](docs/INTEGRATION.md)
* [How to integrate xray-connector in my project?](docs/integration/PROJECT.md)
* [How to set up xray-connector in the CI/CD?](docs/integration/GITLABCI.md)
* [Do I really need xray-connector?](docs/USING_XRAY_API.md)

## ♻️ Contributing

Do you want to evolve this project ? You are more than welcome :-)<br>
Take a look at our [code of conduct to contribute](/docs/CONTRIBUTING.md) and the process for submitting pull requests to us.

If you're up for it, don't hesitate to start looking at this [development information](docs/DEVELOPMENT.md).
